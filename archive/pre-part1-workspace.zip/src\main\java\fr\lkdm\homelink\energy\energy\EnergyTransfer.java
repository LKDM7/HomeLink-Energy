package fr.lkdm.homelink.energy.energy;

import fr.lkdm.homecore.api.energy.EnergyPort;
import org.slf4j.Logger;
import com.mojang.logging.LogUtils;

/**
 * Exact transfer between two HomeCore energy ports: simulate the offer, simulate the acceptance,
 * extract that amount, then insert exactly what was extracted. The amount leaving the source is
 * the amount entering the target; a port that breaks the contract is reported.
 */
public final class EnergyTransfer {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static boolean warned;

    private EnergyTransfer() { }

    /**
     * Moves up to {@code limit} HE from {@code from} to {@code to}.
     *
     * @param from source port
     * @param to target port
     * @param limit most HE to move
     * @return HE moved, extracted from the source and inserted into the target
     */
    public static long move(EnergyPort from, EnergyPort to, long limit) {
        if (limit <= 0 || from == to || !from.type().canSend() || !to.type().canReceive()) return 0;
        long offered = from.extract(limit, true);
        if (offered <= 0) return 0;
        long accepted = to.insert(Math.min(offered, limit), true);
        if (accepted <= 0) return 0;
        long extracted = from.extract(accepted, false);
        if (extracted <= 0) return 0;
        long inserted = to.insert(extracted, false);
        if (inserted != extracted && !warned) {
            warned = true;
            LOGGER.error("Energy port broke the simulate/transfer contract: extracted {} HE but inserted {} HE", extracted, inserted);
        }
        return inserted;
    }
}
