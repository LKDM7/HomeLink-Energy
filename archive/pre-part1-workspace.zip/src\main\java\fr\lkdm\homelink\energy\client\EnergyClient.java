package fr.lkdm.homelink.energy.client;

import fr.lkdm.homelink.energy.HomeLinkEnergy;
import fr.lkdm.homelink.energy.registry.EnergyRegistries;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;

/** Client-only registrations. */
@EventBusSubscriber(modid = HomeLinkEnergy.MOD_ID, value = Dist.CLIENT)
public final class EnergyClient {
    private EnergyClient() { }

    @SubscribeEvent
    public static void screens(RegisterMenuScreensEvent event) {
        event.register(EnergyRegistries.SOLAR_PANEL_MENU.get(), SolarPanelScreen::new);
        event.register(EnergyRegistries.BATTERY_MENU.get(), BatteryScreen::new);
    }
}
