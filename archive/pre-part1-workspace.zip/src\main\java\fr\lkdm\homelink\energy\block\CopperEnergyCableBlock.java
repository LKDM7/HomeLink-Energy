package fr.lkdm.homelink.energy.block;

import com.mojang.serialization.MapCodec;
import fr.lkdm.homecore.api.energy.EnergyApi;
import fr.lkdm.homelink.energy.blockentity.CableBlockEntity;
import fr.lkdm.homelink.energy.network.EnergyNetworks;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.PipeBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Copper Energy Cable: transports HE between the energy ports around it and stores none. It
 * joins other cables and any block exposing a HomeCore energy port on the facing side; it knows
 * nothing about the machines behind those ports.
 */
public final class CopperEnergyCableBlock extends BaseEntityBlock {
    public static final MapCodec<CopperEnergyCableBlock> CODEC = simpleCodec(CopperEnergyCableBlock::new);
    public static final Map<Direction, BooleanProperty> CONNECTIONS = PipeBlock.PROPERTY_BY_DIRECTION;
    private static final VoxelShape CORE = Block.box(5, 5, 5, 11, 11, 11);
    private static final Map<Direction, VoxelShape> ARMS = Map.of(
            Direction.NORTH, Block.box(5, 5, 0, 11, 11, 5),
            Direction.SOUTH, Block.box(5, 5, 11, 11, 11, 16),
            Direction.WEST, Block.box(0, 5, 5, 5, 11, 11),
            Direction.EAST, Block.box(11, 5, 5, 16, 11, 11),
            Direction.DOWN, Block.box(5, 0, 5, 11, 5, 11),
            Direction.UP, Block.box(5, 11, 5, 11, 16, 11));
    private final VoxelShape[] shapes = new VoxelShape[64];

    public CopperEnergyCableBlock(Properties properties) {
        super(properties);
        BlockState state = stateDefinition.any();
        for (BooleanProperty property : CONNECTIONS.values()) state = state.setValue(property, false);
        registerDefaultState(state);
        for (int mask = 0; mask < 64; mask++) {
            VoxelShape shape = CORE;
            for (Direction direction : Direction.values()) {
                if ((mask & 1 << direction.ordinal()) != 0) shape = Shapes.or(shape, ARMS.get(direction));
            }
            shapes[mask] = shape;
        }
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() { return CODEC; }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        CONNECTIONS.values().forEach(builder::add);
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) { return RenderShape.MODEL; }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        int mask = 0;
        for (Direction direction : Direction.values()) if (state.getValue(CONNECTIONS.get(direction))) mask |= 1 << direction.ordinal();
        return shapes[mask];
    }

    /**
     * Whether the cable at {@code pos} joins its neighbour on {@code side}: another cable, or a
     * block exposing an energy port on the face turned towards the cable.
     */
    public static boolean connects(LevelAccessor level, BlockPos pos, Direction side) {
        BlockPos neighbor = pos.relative(side);
        if (level.getBlockState(neighbor).getBlock() instanceof CopperEnergyCableBlock) return true;
        return level instanceof Level world && world.isLoaded(neighbor)
                && world.getCapability(EnergyApi.BLOCK, neighbor, side.getOpposite()) != null;
    }

    private static BlockState withConnections(BlockState state, LevelAccessor level, BlockPos pos) {
        for (Direction direction : Direction.values()) state = state.setValue(CONNECTIONS.get(direction), connects(level, pos, direction));
        return state;
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return withConnections(defaultBlockState(), context.getLevel(), context.getClickedPos());
    }

    @Override
    protected BlockState updateShape(BlockState state, Direction direction, BlockState neighborState, LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        return state.setValue(CONNECTIONS.get(direction), connects(level, pos, direction));
    }

    @Override
    protected void neighborChanged(BlockState state, Level level, BlockPos pos, Block neighbor, BlockPos neighborPos, boolean moved) {
        super.neighborChanged(state, level, pos, neighbor, neighborPos, moved);
        if (level instanceof ServerLevel server) {
            EnergyNetworks.get(server).markDirty(pos);
            BlockState updated = withConnections(state, level, pos);
            if (updated != state) level.setBlock(pos, updated, Block.UPDATE_CLIENTS);
        }
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) { return new CableBlockEntity(pos, state); }
}
