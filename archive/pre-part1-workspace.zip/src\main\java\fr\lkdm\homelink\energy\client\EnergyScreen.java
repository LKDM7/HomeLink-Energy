package fr.lkdm.homelink.energy.client;

import fr.lkdm.homelink.energy.menu.EnergyMenu;
import fr.lkdm.homelink.energy.network.EnergyPayloads;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.client.gui.components.Button;
import net.neoforged.neoforge.network.PacketDistributor;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/** Common look of the HomeLink Energy information screens: anthracite, light gray and copper. */
public abstract class EnergyScreen<M extends EnergyMenu> extends AbstractContainerScreen<M> {
    static final int BACKGROUND = 0xFF26282C;
    static final int PANEL = 0xFF32353A;
    static final int COPPER = 0xFFC7794A;
    static final int TEXT = 0xFFE8E8E8;
    static final int LABEL = 0xFFA4A8AE;
    static final int GOOD = 0xFF6FA8DC;
    static final int WARN = 0xFFE0B050;
    static final int BAD = 0xFFD9534F;
    static final int LINE = 12;

    private int line;

    protected EnergyScreen(M menu, Inventory inventory, Component title, int height) {
        super(menu, inventory, title);
        imageWidth = 208;
        imageHeight = height;
    }

    @Override
    protected void init() {
        super.init();
        addRenderableWidget(Button.builder(networkLabel(), button -> cycleNetwork())
                .bounds(leftPos + 8, topPos + imageHeight - 26, imageWidth - 16, 18).build());
    }

    private Component networkLabel() {
        String current = EnergyClientData.choices(menu.pos()).current();
        return Component.translatable("gui.homelink_energy.home_network",
                current.isEmpty() ? Component.translatable("gui.homelink_energy.home_network.none") : Component.literal(current));
    }

    /** Asks the server to move the block to the next HomeNetwork the player manages (then none). */
    private void cycleNetwork() {
        var data = EnergyClientData.choices(menu.pos());
        var choices = data.choices();
        if (choices.isEmpty() && data.current().isEmpty()) {
            if (minecraft != null && minecraft.player != null)
                minecraft.player.displayClientMessage(Component.translatable("message.homelink_energy.network.no_choices"), true);
            return;
        }
        int index = -1;
        for (int i = 0; i < choices.size(); i++) if (choices.get(i).name().equals(data.current())) index = i;
        Optional<UUID> next = index + 1 < choices.size() ? Optional.of(choices.get(index + 1).id()) : Optional.empty();
        PacketDistributor.sendToServer(new EnergyPayloads.Bind(menu.pos(), next));
    }

    @Override
    public void containerTick() {
        super.containerTick();
        for (var child : children()) if (child instanceof Button button) button.setMessage(networkLabel());
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        graphics.fill(leftPos - 1, topPos - 1, leftPos + imageWidth + 1, topPos + imageHeight + 1, COPPER);
        graphics.fill(leftPos, topPos, leftPos + imageWidth, topPos + imageHeight, BACKGROUND);
        graphics.fill(leftPos + 6, topPos + 20, leftPos + imageWidth - 6, topPos + imageHeight - 30, PANEL);
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
        graphics.drawString(font, title, 8, 7, COPPER, false);
        line = 26;
        renderLines(graphics);
    }

    /** Draws the body lines, in order, with {@link #row} and {@link #bar}. */
    protected abstract void renderLines(GuiGraphics graphics);

    /** Draws a "label: value" row. */
    protected void row(GuiGraphics graphics, Component label, Component value, int valueColor) {
        graphics.drawString(font, label, 12, line, LABEL, false);
        graphics.drawString(font, value, imageWidth - 12 - font.width(value), line, valueColor, false);
        line += LINE;
    }

    /** Draws a horizontal gauge. */
    protected void bar(GuiGraphics graphics, double fraction, int color) {
        int left = 12, right = imageWidth - 12, top = line + 1;
        graphics.fill(left, top, right, top + 8, 0xFF1B1C1F);
        int filled = (int) Math.round((right - left - 2) * Math.max(0, Math.min(1, fraction)));
        if (filled > 0) graphics.fill(left + 1, top + 1, left + 1 + filled, top + 7, color);
        line += LINE;
    }

    /** Draws the cable network connection row. */
    protected void network(GuiGraphics graphics, int ordinal) {
        var states = fr.lkdm.homelink.energy.network.EnergyNetworks.Connection.values();
        var state = ordinal >= 0 && ordinal < states.length ? states[ordinal] : states[0];
        int color = switch (state) { case CONNECTED -> GOOD; case NONE -> LABEL; case NETWORK_TOO_LARGE -> BAD; };
        row(graphics, Component.translatable("gui.homelink_energy.network"),
                Component.translatable("gui.homelink_energy.network." + state.name().toLowerCase(java.util.Locale.ROOT)), color);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
    }
}
