package fr.lkdm.homelink.energy.verification;

import static fr.lkdm.homelink.energy.verification.EnergyValidation.charge;
import static fr.lkdm.homelink.energy.verification.EnergyValidation.check;
import static fr.lkdm.homelink.energy.verification.EnergyValidation.place;
import static fr.lkdm.homelink.energy.verification.EnergyValidation.world;

import fr.lkdm.homelink.energy.HomeLinkEnergy;
import fr.lkdm.homelink.energy.block.CopperEnergyCableBlock;
import fr.lkdm.homelink.energy.blockentity.BatteryBlockEntity;
import fr.lkdm.homelink.energy.blockentity.CableBlockEntity;
import fr.lkdm.homelink.energy.blockentity.SolarPanelBlockEntity;
import fr.lkdm.homelink.energy.config.EnergyConfig;
import fr.lkdm.homelink.energy.network.EnergyNetworks;
import fr.lkdm.homelink.energy.registry.EnergyRegistries;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

/**
 * Part 2: cable networks. Most tests run at night with pre-filled buffers so that no new
 * production interferes: every HE is accounted for exactly.
 */
@GameTestHolder(EnergyValidation.MOD_ID)
@PrefixGameTestTemplate(false)
public final class NetworkGameTests {
    private static void night(GameTestHelper helper) { world(helper, 18_000, false, false); }

    private static void cables(GameTestHelper helper, int x0, int x1, int y, int z) {
        for (int x = x0; x <= x1; x++) helper.setBlock(new BlockPos(x, y, z), EnergyRegistries.COPPER_ENERGY_CABLE.get());
    }

    private static EnergyNetworks networks(GameTestHelper helper) { return EnergyNetworks.get(helper.getLevel()); }

    @GameTest(template = "empty", batch = "net_1", timeoutTicks = 100)
    public static void cablesConnectVisuallyToPortsOnly(GameTestHelper helper) {
        night(helper);
        place(helper, EnergyRegistries.BATTERY_1.get(), new BlockPos(0, 1, 0));
        cables(helper, 1, 2, 1, 0);
        place(helper, EnergyRegistries.SOLAR_PANEL_1.get(), new BlockPos(2, 2, 0));
        helper.setBlock(new BlockPos(1, 1, 1), Blocks.STONE);
        var first = helper.getBlockState(new BlockPos(1, 1, 0));
        check(helper, first.getValue(CopperEnergyCableBlock.CONNECTIONS.get(Direction.WEST)), "Cable not joined to the battery");
        check(helper, first.getValue(CopperEnergyCableBlock.CONNECTIONS.get(Direction.EAST)), "Cable not joined to the next cable");
        check(helper, !first.getValue(CopperEnergyCableBlock.CONNECTIONS.get(Direction.SOUTH)), "Cable joined to plain stone");
        check(helper, helper.getBlockState(new BlockPos(2, 1, 0)).getValue(CopperEnergyCableBlock.CONNECTIONS.get(Direction.UP)), "Cable not joined to the panel's bottom output");
        helper.succeed();
    }

    @GameTest(template = "empty", batch = "net_2", timeoutTicks = 100)
    public static void producerFeedsConsumerExactly(GameTestHelper helper) {
        night(helper);
        SolarPanelBlockEntity panel = place(helper, EnergyRegistries.SOLAR_PANEL_3.get(), new BlockPos(0, 2, 0));
        panel.core().buffer().setStored(1_000);
        cables(helper, 0, 3, 1, 0);
        TestConsumer consumer = place(helper, EnergyValidation.CONSUMER.get(), new BlockPos(4, 1, 0));
        consumer.demand = 10;
        helper.runAfterDelay(30, () -> {
            check(helper, consumer.received > 0, "Consumer received nothing");
            check(helper, panel.core().buffer().stored() + consumer.received == 1_000,
                    "Not conserved: buffer " + panel.core().buffer().stored() + " + consumer " + consumer.received);
            check(helper, consumer.received % 10 == 0, "The consumer got more than it asked for in a tick: " + consumer.received);
            helper.succeed();
        });
    }

    @GameTest(template = "empty", batch = "net_3", timeoutTicks = 100)
    public static void surplusChargesBatteriesAfterConsumers(GameTestHelper helper) {
        night(helper);
        SolarPanelBlockEntity panel = place(helper, EnergyRegistries.SOLAR_PANEL_3.get(), new BlockPos(0, 2, 0));
        panel.core().buffer().setStored(1_000);
        cables(helper, 0, 3, 1, 0);
        TestConsumer consumer = place(helper, EnergyValidation.CONSUMER.get(), new BlockPos(4, 1, 0));
        consumer.demand = 3;
        BatteryBlockEntity battery = place(helper, EnergyRegistries.BATTERY_1.get(), new BlockPos(2, 1, 1));
        helper.runAfterDelay(25, () -> {
            long total = panel.core().buffer().stored() + consumer.received + battery.stored();
            check(helper, total == 1_000, "Not conserved: " + total);
            check(helper, consumer.received >= 3 * 20, "Consumer starved: " + consumer.received);
            check(helper, battery.stored() > 0 && battery.stored() <= 8L * 25, "Battery I charge must respect 8 HE/t: " + battery.stored());
            helper.succeed();
        });
    }

    @GameTest(template = "empty", batch = "net_4", timeoutTicks = 100)
    public static void batteriesCoverTheDeficitWithinTheirRate(GameTestHelper helper) {
        night(helper);
        BatteryBlockEntity battery = place(helper, EnergyRegistries.BATTERY_1.get(), new BlockPos(0, 1, 0));
        charge(helper, battery, 1_000);
        cables(helper, 1, 3, 1, 0);
        TestConsumer consumer = place(helper, EnergyValidation.CONSUMER.get(), new BlockPos(4, 1, 0));
        consumer.demand = 100;
        helper.runAfterDelay(21, () -> {
            check(helper, battery.stored() + consumer.received == 1_000, "Not conserved");
            check(helper, consumer.received > 0 && consumer.received % 8 == 0 && consumer.received <= 8 * 21,
                    "Battery I must discharge at most 8 HE/t: " + consumer.received);
            helper.succeed();
        });
    }

    @GameTest(template = "empty", batch = "net_5", timeoutTicks = 100)
    public static void batteriesNeverFeedEachOther(GameTestHelper helper) {
        night(helper);
        BatteryBlockEntity full = place(helper, EnergyRegistries.BATTERY_3.get(), new BlockPos(0, 1, 0));
        charge(helper, full, 50_000);
        cables(helper, 1, 3, 1, 0);
        BatteryBlockEntity empty = place(helper, EnergyRegistries.BATTERY_3.get(), new BlockPos(4, 1, 0));
        helper.runAfterDelay(40, () -> {
            check(helper, full.stored() == 50_000 && empty.stored() == 0, "Battery to battery transfer: " + full.stored() + " / " + empty.stored());
            check(helper, networks(helper).networksOfMachine(helper.absolutePos(new BlockPos(0, 1, 0))).size() == 1, "Battery not in the network");
            helper.succeed();
        });
    }

    @GameTest(template = "empty", batch = "net_6", timeoutTicks = 200)
    public static void brokenCableSplitsAndReplacedCableMerges(GameTestHelper helper) {
        night(helper);
        BatteryBlockEntity battery = place(helper, EnergyRegistries.BATTERY_2.get(), new BlockPos(0, 1, 0));
        charge(helper, battery, 5_000);
        cables(helper, 1, 5, 1, 0);
        TestConsumer consumer = place(helper, EnergyValidation.CONSUMER.get(), new BlockPos(6, 1, 0));
        consumer.demand = 4;
        BlockPos middle = new BlockPos(3, 1, 0);
        helper.runAfterDelay(10, () -> {
            check(helper, consumer.received > 0, "Not delivering before the break");
            helper.destroyBlock(middle);
            helper.runAfterDelay(2, () -> {
                long afterBreak = consumer.received;
                var level = helper.getLevel();
                var left = networks(helper).networkOfCable(helper.absolutePos(new BlockPos(2, 1, 0)));
                var right = networks(helper).networkOfCable(helper.absolutePos(new BlockPos(4, 1, 0)));
                check(helper, left.isPresent() && right.isPresent() && left.get() != right.get(), "Network did not split");
                helper.runAfterDelay(10, () -> {
                    check(helper, consumer.received == afterBreak, "Energy crossed a broken cable");
                    check(helper, battery.stored() + consumer.received == 5_000, "Split lost or created energy");
                    helper.setBlock(middle, EnergyRegistries.COPPER_ENERGY_CABLE.get());
                    helper.runAfterDelay(10, () -> {
                        check(helper, consumer.received > afterBreak, "Merged network does not deliver");
                        check(helper, networks(helper).networkOfCable(helper.absolutePos(new BlockPos(2, 1, 0)))
                                .equals(networks(helper).networkOfCable(helper.absolutePos(new BlockPos(4, 1, 0)))), "Network did not merge");
                        check(helper, battery.stored() + consumer.received == 5_000, "Merge lost or created energy");
                        check(helper, level.getBlockEntity(helper.absolutePos(middle)) instanceof CableBlockEntity, "Cable entity");
                        helper.succeed();
                    });
                });
            });
        });
    }

    @GameTest(template = "empty", batch = "net_7", timeoutTicks = 200)
    public static void unloadedCableStopsTheFlowWithoutFreeEnergy(GameTestHelper helper) {
        night(helper);
        BatteryBlockEntity battery = place(helper, EnergyRegistries.BATTERY_2.get(), new BlockPos(0, 1, 0));
        charge(helper, battery, 2_000);
        cables(helper, 1, 5, 1, 0);
        TestConsumer consumer = place(helper, EnergyValidation.CONSUMER.get(), new BlockPos(6, 1, 0));
        consumer.demand = 4;
        CableBlockEntity middle = helper.getBlockEntity(new BlockPos(3, 1, 0));
        helper.runAfterDelay(5, () -> {
            // The same hook the chunk unload runs: the cable leaves the graph, nothing is loaded.
            middle.onChunkUnloaded();
            helper.runAfterDelay(2, () -> {
                long frozen = consumer.received;
                long stored = battery.stored();
                helper.runAfterDelay(20, () -> {
                    check(helper, consumer.received == frozen && battery.stored() == stored, "Energy crossed an unloaded cable");
                    middle.onLoad();
                    helper.runAfterDelay(5, () -> {
                        check(helper, consumer.received > frozen, "Reloaded cable does not carry energy");
                        check(helper, battery.stored() + consumer.received == 2_000, "Not conserved over unload/reload");
                        helper.succeed();
                    });
                });
            });
        });
    }

    @GameTest(template = "empty", batch = "net_limit", timeoutTicks = 100)
    public static void oversizedNetworkStopsCleanly(GameTestHelper helper) {
        night(helper);
        int previous = EnergyConfig.MAX_ENERGY_NETWORK_NODES.get();
        EnergyConfig.MAX_ENERGY_NETWORK_NODES.set(8);
        BatteryBlockEntity battery = place(helper, EnergyRegistries.BATTERY_1.get(), new BlockPos(0, 1, 0));
        charge(helper, battery, 1_000);
        cables(helper, 1, 8, 1, 0);
        TestConsumer consumer = place(helper, EnergyValidation.CONSUMER.get(), new BlockPos(9, 1, 0));
        helper.runAfterDelay(10, () -> {
            try {
                var network = networks(helper).networkOfCable(helper.absolutePos(new BlockPos(4, 1, 0))).orElseThrow();
                check(helper, network.tooLarge(), "10 nodes over a limit of 8 must be NETWORK_TOO_LARGE");
                check(helper, consumer.received == 0 && battery.stored() == 1_000, "An oversized network moved energy");
                check(helper, battery.networkConnection() == EnergyNetworks.Connection.NETWORK_TOO_LARGE, "Battery state " + battery.networkConnection());
                helper.succeed();
            } finally {
                EnergyConfig.MAX_ENERGY_NETWORK_NODES.set(previous);
            }
        });
    }

    @GameTest(template = "empty", batch = "net_8", timeoutTicks = 60)
    public static void batteryCapacitiesAndOverflowClamp(GameTestHelper helper) {
        night(helper);
        BatteryBlockEntity b1 = place(helper, EnergyRegistries.BATTERY_1.get(), new BlockPos(0, 1, 0));
        BatteryBlockEntity b2 = place(helper, EnergyRegistries.BATTERY_2.get(), new BlockPos(2, 1, 0));
        BatteryBlockEntity b3 = place(helper, EnergyRegistries.BATTERY_3.get(), new BlockPos(4, 1, 0));
        check(helper, b1.capacity() == 40_000 && b2.capacity() == 120_000 && b3.capacity() == 320_000, "Capacities");
        check(helper, b1.stored() == 0 && b2.stored() == 0 && b3.stored() == 0, "Batteries start empty");
        charge(helper, b3, Long.MAX_VALUE);
        check(helper, b3.stored() == 320_000, "Overflowing save not clamped: " + b3.stored());
        charge(helper, b2, -50);
        check(helper, b2.stored() == 0, "Negative save not clamped");
        check(helper, b3.port(null).insert(1, false) == 0, "Full battery accepted energy");
        check(helper, b1.port(null).insert(1_000, false) == 8 && b2.port(null).insert(1_000, false) == 32, "Charge limits 8 / 32");
        check(helper, b3.port(null).extract(1_000, false) == 128, "Discharge limit 128");
        helper.runAfterDelay(30, () -> {
            check(helper, b1.stored() == 8, "Battery I changed by itself: " + b1.stored());
            helper.succeed();
        });
    }

    @GameTest(template = "empty", batch = "net_id", timeoutTicks = 40)
    public static void namespace(GameTestHelper helper) {
        check(helper, HomeLinkEnergy.id("copper_energy_cable").equals(net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(EnergyRegistries.COPPER_ENERGY_CABLE.get())), "Cable id");
        helper.succeed();
    }
}
