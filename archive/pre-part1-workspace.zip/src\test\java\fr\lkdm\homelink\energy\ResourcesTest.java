package fr.lkdm.homelink.energy;

import static org.junit.jupiter.api.Assertions.*;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.junit.jupiter.api.Test;

/** Static checks of the shipped resources: translations, models, textures, loot tables. */
class ResourcesTest {
    private static final Path ASSETS = Path.of(System.getProperty("user.dir")).resolve(locate("src/main/resources/assets/homelink_energy"));
    private static final Path DATA = ASSETS.getParent().getParent().resolve("data/homelink_energy");
    private static final List<String> BLOCKS = List.of("solar_panel_1", "solar_panel_2", "solar_panel_3",
            "battery_1", "battery_2", "battery_3", "copper_energy_cable");

    /** Unit tests may run from the project or from its run directory. */
    private static Path locate(String relative) {
        Path here = Path.of(System.getProperty("user.dir"));
        for (Path dir = here; dir != null; dir = dir.getParent()) {
            if (Files.isDirectory(dir.resolve(relative))) return dir.resolve(relative);
        }
        throw new IllegalStateException("Resources not found from " + here);
    }

    private static JsonObject json(Path path) throws IOException {
        return JsonParser.parseString(Files.readString(path)).getAsJsonObject();
    }

    @Test void translationsHaveTheSameKeys() throws IOException {
        var en = json(ASSETS.resolve("lang/en_us.json")).keySet();
        var fr = json(ASSETS.resolve("lang/fr_fr.json")).keySet();
        assertEquals(en, fr, "en_us and fr_fr differ");
        for (String block : BLOCKS) assertTrue(en.contains("block.homelink_energy." + block), "Missing name for " + block);
    }

    @Test void everyBlockHasItsAssetsAndLootTable() {
        for (String block : BLOCKS) {
            assertTrue(Files.isRegularFile(ASSETS.resolve("blockstates/" + block + ".json")), "Blockstate " + block);
            assertTrue(Files.isRegularFile(ASSETS.resolve("models/item/" + block + ".json")), "Item model " + block);
            assertTrue(Files.isRegularFile(DATA.resolve("loot_table/blocks/" + block + ".json")), "Loot table " + block);
            assertTrue(Files.isRegularFile(DATA.resolve("recipe/" + block + ".json")), "Recipe " + block);
        }
    }

    @Test void everyReferencedModelAndTextureExists() throws IOException {
        Pattern reference = Pattern.compile("\"homelink_energy:((?:block|item)/[a-z0-9_/]+)\"");
        List<String> missing = new ArrayList<>();
        try (var files = Files.walk(ASSETS)) {
            for (Path file : files.filter(p -> p.toString().endsWith(".json") && !p.toString().contains("lang")).toList()) {
                Matcher matcher = reference.matcher(Files.readString(file));
                while (matcher.find()) {
                    String path = matcher.group(1);
                    boolean model = Files.isRegularFile(ASSETS.resolve("models/" + path + ".json"));
                    boolean texture = Files.isRegularFile(ASSETS.resolve("textures/" + path + ".png"));
                    if (!model && !texture) missing.add(file.getFileName() + " -> " + path);
                }
            }
        }
        assertTrue(missing.isEmpty(), "Missing references: " + missing);
    }
}
